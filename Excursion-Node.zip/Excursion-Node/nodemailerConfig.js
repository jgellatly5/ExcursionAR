module.exports = {
    mailUser: 'jgellatly5@gmail.com',
    mailPass: 'beloteca1992'
}
